# FFmpeg API scaffold
